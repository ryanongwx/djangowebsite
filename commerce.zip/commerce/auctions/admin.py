from django.contrib import admin
from .models import Comments, Listing, Bidding
# Register your models here.

admin.site.register(Comments)
admin.site.register(Bidding)
admin.site.register(Listing)
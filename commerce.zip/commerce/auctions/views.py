from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django import forms
from django.core.exceptions import ValidationError

from .models import Listing, User, Comments, Bidding

def index(request):
    if request.method == 'POST':
        form = Listingform(request.POST)
        if form.is_valid():
            title = form.cleaned_data['title']
            description = form.cleaned_data['description']
            imageurl = form.cleaned_data['imageurl']
            category = form.cleaned_data['category']
            startingbid = form.cleaned_data['startingbid']
            user = form.cleaned_data['user']
            status = "open"
            k = Listing(title=title, description=description, category=category, picture=imageurl, price=startingbid, user=user, status=status)
            k.save()

    return render(request, "auctions/index.html", {
        "listings": Listing.objects.all(),
        'watchlist': mywatchlist
    })


def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("auctions:index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "auctions/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("auctions:index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("auctions:index"))
    else:
        return render(request, "auctions/register.html")


def newlisting(request):
    return render(request, "auctions/newlisting.html", {
        "listings": Listing.objects.all(),
        "listingform": Listingform()
    })

class Listingform(forms.Form):
    title = forms.CharField(max_length=64)
    description = forms.CharField(widget=forms.Textarea, max_length=1000)
    startingbid = forms.FloatField()
    category = forms.CharField(max_length=64)
    imageurl = forms.CharField(max_length=100, label="Image Url")
    user = forms.CharField(max_length=64)


def individual(request, listingid):
    if request.method == "POST":
        form1 = Biddingform(request.POST)
        form2 = CommentForm(request.POST)
        if form1.is_valid():
            newbid = form1.cleaned_data['newbid']
            currentbid = form1.cleaned_data['currentbid']
            itemid = form1.cleaned_data['itemid']
            user = form1.cleaned_data['user']
            p = Bidding(itemid=itemid, currentbid=currentbid, newbid=newbid, user=user)
            p.save()
            w = Listing.objects.get(id=listingid)
            w.price = newbid
            w.save()
            HttpResponse("Bid has been made")
        if form2.is_valid():
            comments = form2.cleaned_data['comments']
            k = Comments(comment=comments, itemid=listingid)
            k.save()
    return render(request, "auctions/individual.html", {
        'id': listingid,
        'listing': Listing.objects.get(id=listingid),
        'form1': Biddingform(),
        'commentform': CommentForm(),
        'comments': Comments.objects.filter(itemid=listingid)
    })


mywatchlist = []


def watchlist(request, listingid, action):
    if action == "add" and Listing.objects.get(id=listingid) not in mywatchlist:
        mywatchlist.append(Listing.objects.get(id=listingid))
    if action == "remove":
        mywatchlist.remove(Listing.objects.get(id=listingid))
    return render(request, "auctions/watchlist.html", {
        'watchlist': mywatchlist,
        'listingid': listingid
    })

def bidding(request, listingid):
    return render(request, "auctions/bidding.html", {
        'listingid': listingid
    })


class Biddingform(forms.Form):
    itemid = forms.IntegerField()
    currentbid = forms.IntegerField()
    newbid = forms.IntegerField()

def categories(request):
    allcats = []
    all = Listing.objects.all()
    for i in all:
        allcats.append(i.category)
    allcategories = list(dict.fromkeys(allcats))
    # Create a dictionary, using the List items as keys.
    # This will automatically remove any duplicates because dictionaries cannot have duplicate keys.
    return render(request, "auctions/categories.html", {
        'listings': allcategories
    })

def category(request, cat):
    return render(request, "auctions/category.html", {
        'cat': cat,
        'listings': Listing.objects.filter(category=cat)
    })

class CommentForm(forms.Form):
    comments = forms.CharField(widget=forms.Textarea, label="")

def closeauction(request, listingid):
    item = Listing.objects.get(id=listingid)
    item.status = "closed"
    item.save()
    biduser = Bidding.objects.get(id=listingid)
    return render(request, "auctions/individual.html", {
        'listing': item,
        'biduser': biduser
    })
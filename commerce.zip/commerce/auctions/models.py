from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    pass

class Listing(models.Model):
    title = models.CharField(max_length=64)
    description = models.CharField(max_length=1000)
    picture = models.CharField(max_length=1000)
    price = models.FloatField(max_length=64)
    category = models.CharField(max_length=64)
    user = models.CharField(max_length=64)
    status = models.CharField(max_length=64)

    def __str__(self):
        return f"{self.title} : ${self.price}"


class Comments(models.Model):
    comment = models.CharField(max_length=1000)
    itemid = models.IntegerField()

    def __str__(self):
        return f"Listing {self.itemid} : {self.comment}"


class Bidding(models.Model):
    itemid = models.IntegerField()
    currentbid = models.IntegerField()
    newbid = models.IntegerField()
    user = models.CharField(max_length=64)

    def __str__(self):
        return f"{self.user} increased bid for Listing {self.itemid} from ${self.currentbid} to ${self.newbid}"
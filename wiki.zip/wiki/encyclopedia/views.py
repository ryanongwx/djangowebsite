from django.shortcuts import render
from django import forms
from django.http import HttpResponseRedirect, HttpResponse
import random

from . import util

def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries(),
        "form": Form()

    })
# util.list_entries return a list of all the markdown files

def title(request, title):
    url = "encyclopedia/html.html"
    if request.method == "POST":
        form = EditPage(request.POST)
        if form.is_valid():
            editedcontent = form.cleaned_data['pagecontent']
            pagename = form.cleaned_data['pagename']
            util.save_entry(pagename, editedcontent)
            return render(request, url, {
                "titlecontent": util.get_entry(title),
                "title": title,
                "form": Form()
            })

    return render(request, url, {
        "titlecontent": util.get_entry(title),
        "title": title,
        "form": Form()

    })

def search(request):
    searchresults = []
    if request.method == "POST":
        form = Form(request.POST)
        if form.is_valid():
            search1 = form.cleaned_data['searchresult']
            if search1 in util.list_entries():
                url1 = "wiki/" + search1
                return HttpResponseRedirect(url1, {
                    "titlecontent": util.get_entry(search1),
                    "title": search1,
                })
            else:
                for entry in util.list_entries():
                    if search1 in entry:
                        searchresults.append(entry)
        else:
            return render(request, "encyclopedia/search.html", {
                "form": form,
            })
    return render(request, "encyclopedia/search.html",{
        "entries": util.list_entries(),
        "form": Form(),
        "searchresults": searchresults
    })

class Form(forms.Form):
    searchresult = forms.CharField(label="Search Encyclopedia")


def createnewpage(request):
    if request.method == "POST":
        form2 = NewPage(request.POST)
        if form2.is_valid():
            pagetitle1 = form2.cleaned_data['pagetitle']
            pagecontent1 = form2.cleaned_data['pagecontent']
            if pagetitle1 not in util.list_entries():
                util.save_entry(pagetitle1, pagecontent1)
                url2 = "wiki/" + pagetitle1
                return HttpResponseRedirect(url2, {
                    "titlecontent": util.get_entry(pagetitle1),
                    "title": pagetitle1,
                })
            else:
                return HttpResponse("This page already exists, try another page name.")
        else:
            return render(request, "createnewpage", {
                "form": form2,
            })

    return render(request, "encyclopedia/createnewpage.html", {
        "form": Form(),
        "form2": NewPage()
    })

class NewPage(forms.Form):
    pagetitle = forms.CharField(label="Title of Page")
    pagecontent = forms.CharField(widget=forms.Textarea, label="Content of Page")

def edit(request, title):
    return render(request, "encyclopedia/editpage.html", {
        "content": util.get_entry(title),
        "title": title,
        "form": Form(),
        "form3": EditPage(initial={'pagecontent': util.get_entry(title), 'pagename': title})
    })

class EditPage(forms.Form):
    pagename = forms.CharField(label="")
    pagecontent = forms.CharField(widget=forms.Textarea, label="")


def randompage(request):
    randomlist = util.list_entries()
    page = random.choice(randomlist)
    return HttpResponseRedirect("wiki/" + page)